export const environment = {
	production: true,

	baseUrl: 'http://localhost:12001/api',
};
// baseUrl: 'https://inv.chronoswinvestment.com/api'
// baseUrl: 'http://localhost:12001/api'
// baseUrl: 'https://chronoswinvestment.herokuapp.com/api'
// 	baseUrl: "https://invdaq.com/api",
// baseUrl: 'https://Inaqstock.com/api',
//
