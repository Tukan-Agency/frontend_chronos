export interface trimestre {
    id: string;
    name: string;
}