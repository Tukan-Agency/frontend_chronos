import { Component } from '@angular/core';

@Component({
  selector: 'app-reporte-page',
  templateUrl: './reporte.component.html'
})
export class ReportePageComponent {}
