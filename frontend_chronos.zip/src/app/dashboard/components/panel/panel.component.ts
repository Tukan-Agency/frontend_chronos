import { Component, OnInit } from '@angular/core';
import { trimestre } from '../../interfaces/trimestre';

@Component({
  selector: 'app-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.css']
})
export class PanelComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {
    
  }
}
