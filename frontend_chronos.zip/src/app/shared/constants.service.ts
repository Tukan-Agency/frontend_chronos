export class ConstantsService {
    static MAIN_PATH = 'main';
}